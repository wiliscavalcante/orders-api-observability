require('./otel.js');

const express = require('express');
const pino = require('pino');
const swaggerUi = require('swagger-ui-express');
const YAML = require('yamljs');
const app = express();
const logger = pino();

const swaggerDocument = YAML.load('./swagger.yaml');
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.use(express.json());

app.get('/orders', (req, res) => {
  logger.info({ trace_id: req.headers['x-trace-id'] || 'unknown' }, 'Received GET /orders');
  res.json({ status: 'success', data: [{ id: 1, item: 'coffee' }] });
});

app.get('/orders/fail', (req, res) => {
  logger.error({ trace_id: req.headers['x-trace-id'] || 'unknown' }, 'Simulated failure at /orders/fail');
  res.status(500).json({ error: 'internal server error' });
});

app.listen(3000, () => {
  logger.info('Observability Lab App listening on port 3000');
});